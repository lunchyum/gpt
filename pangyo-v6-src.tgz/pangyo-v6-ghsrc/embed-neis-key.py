#!/usr/bin/env python3
"""AppConfig.java에 NEIS 인증키를 넣는 로컬 도구입니다."""
from __future__ import print_function

import getpass
import os
import re
from pathlib import Path

config = Path(__file__).parent / "app/src/main/java/kr/pangyo/weekwall/AppConfig.java"
key = os.environ.get("NEIS_API_KEY") or getpass.getpass("NEIS_API_KEY (화면에 표시되지 않음): ")
key = key.strip()
if not key:
    raise SystemExit("인증키가 비어 있습니다.")
if len(key) > 300:
    raise SystemExit("인증키 길이가 비정상적으로 깁니다.")

escaped = key.replace("\\", "\\\\").replace('"', '\\"')
text = config.read_text(encoding="utf-8")
new_text, count = re.subn(
    r'public static final String NEIS_API_KEY = ".*?";',
    'public static final String NEIS_API_KEY = "{}";'.format(escaped),
    text,
    count=1,
)
if count != 1:
    raise SystemExit("AppConfig.java의 인증키 항목을 찾지 못했습니다.")
config.write_text(new_text, encoding="utf-8")
print("인증키를 AppConfig.java에 내장했습니다. Android Studio에서 APK를 다시 빌드하세요.")
